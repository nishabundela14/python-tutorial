from flask import Flask, render_template
import os

app = Flask(__name__)

pic_place = os.path.join('static')


# @app.route("/")
# def home():
#     pic = os.path.join(pic_place, 'image1.png')
#     return render_template('home.html', user_img=pic)

# @app.route("/second")
# def second():
#     return "welcome to new page"

@app.route("/")
def homes():
    return render_template('index.html')

if __name__ == "__main__":
    app.run()