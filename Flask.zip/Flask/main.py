from flask import Flask, render_template,request

web = Flask(__name__)


@web.route('/')
@web.route('/register')

def home():
    return render_template('register.html')


@web.route('/confirmation', methods=['POST', 'GET'])

def confirm():
    if request.method == 'POST':
        n = request.form.get('name')
        c = request.form.get('city')
        p = request.form.get('phone')
        return render_template('confirmation.html', name=n, city=c, phone=p)

if __name__ == "__main__":
    web.run(debug=True)